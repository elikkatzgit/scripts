#!/bin/bash
#elkatz
#2018-03-20 Update MSTR dashboard country names

sql_file=mstr_countries.sql
output=`grep -h spool $sql_file |head -1 |awk '{print$2}'`

cat > $output <<EOL
{
        "Name": "countries",
        "Key": "iso-a2",
        "synonyms": {
EOL
/software/oracle/112/bin/sqlplus DEU_O2QQQ_SPARX/DEU_O2QQQ_SPARX@igt @"$sql_file"

#mv $output /starhome/igateprov/webapps/MicroStrategy/plugins/VitaraMaps/custom/dictionaries/$output
