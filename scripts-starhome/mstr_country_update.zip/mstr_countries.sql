spool /starhome/support/countries-test.txt append
SET NEWPAGE 0
SET SPACE 0
SET LINESIZE 100
SET PAGESIZE 0
SET ECHO OFF
SET FEEDBACK OFF
SET HEADING OFF

select '"' ||iso3166_a2|| '": ["' || country_name || '"],' from gsm_countries
where iso3166_a2 <> 'IN'
order by 1;
SELECT '"' ||iso3166_a2|| '": ["' || LISTAGG(country_name,'","')
WITHIN GROUP (ORDER BY iso3166_a2) ||'"]  } }' AS description
FROM gsm_countries where iso3166_a2 ='IN' GROUP BY iso3166_a2;
 
spool off
exit
